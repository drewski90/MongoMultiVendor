from .builder import AdminBuilder

Admin = AdminBuilder()

__all__ = [
  "Admin"
]