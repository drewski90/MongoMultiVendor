from .model_view import UserModelView

class UserGroupView(UserModelView):
  pass